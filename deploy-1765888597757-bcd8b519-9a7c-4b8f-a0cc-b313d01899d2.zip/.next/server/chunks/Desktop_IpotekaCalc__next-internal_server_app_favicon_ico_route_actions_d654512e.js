module.exports=[26862,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_IpotekaCalc__next-internal_server_app_favicon_ico_route_actions_d654512e.js.map