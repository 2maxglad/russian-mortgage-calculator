module.exports=[3285,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_IpotekaCalc__next-internal_server_app_api_cbr_route_actions_346dd46c.js.map