module.exports=[97217,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_IpotekaCalc__next-internal_server_app_page_actions_7dd127b1.js.map