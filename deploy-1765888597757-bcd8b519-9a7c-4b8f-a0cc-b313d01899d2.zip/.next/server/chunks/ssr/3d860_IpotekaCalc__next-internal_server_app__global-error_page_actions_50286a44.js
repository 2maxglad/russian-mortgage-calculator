module.exports=[83734,(a,b,c)=>{}];

//# sourceMappingURL=3d860_IpotekaCalc__next-internal_server_app__global-error_page_actions_50286a44.js.map