module.exports=[13456,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_IpotekaCalc__next-internal_server_app__not-found_page_actions_acd7ddcd.js.map