var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/prices/route.js")
R.c("server/chunks/[root-of-the-server]__695857d2._.js")
R.c("server/chunks/[root-of-the-server]__e6e8ead8._.js")
R.c("server/chunks/Desktop_IpotekaCalc__next-internal_server_app_api_prices_route_actions_9139b145.js")
R.m(53480)
module.exports=R.m(53480).exports
