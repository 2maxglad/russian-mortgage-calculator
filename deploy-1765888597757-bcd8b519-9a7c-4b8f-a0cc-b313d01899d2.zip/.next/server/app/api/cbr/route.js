var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cbr/route.js")
R.c("server/chunks/[root-of-the-server]__7e4b2c11._.js")
R.c("server/chunks/[root-of-the-server]__e6e8ead8._.js")
R.c("server/chunks/Desktop_IpotekaCalc__next-internal_server_app_api_cbr_route_actions_346dd46c.js")
R.m(4648)
module.exports=R.m(4648).exports
