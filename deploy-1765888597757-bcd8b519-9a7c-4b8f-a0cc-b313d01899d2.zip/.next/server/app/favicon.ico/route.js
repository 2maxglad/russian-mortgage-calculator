var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__8dbe5856._.js")
R.c("server/chunks/[root-of-the-server]__e6e8ead8._.js")
R.c("server/chunks/7d77c_next_dist_esm_build_templates_app-route_22296e3f.js")
R.c("server/chunks/Desktop_IpotekaCalc__next-internal_server_app_favicon_ico_route_actions_d654512e.js")
R.m(10104)
module.exports=R.m(10104).exports
