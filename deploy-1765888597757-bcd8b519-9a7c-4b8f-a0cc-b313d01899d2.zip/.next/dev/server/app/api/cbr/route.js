var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cbr/route.js")
R.c("server/chunks/7d77c_next_e45d4959._.js")
R.c("server/chunks/[root-of-the-server]__9cf8c20a._.js")
R.c("server/chunks/Desktop_IpotekaCalc__next-internal_server_app_api_cbr_route_actions_346dd46c.js")
R.m("[project]/Desktop/IpotekaCalc/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/IpotekaCalc/src/app/api/cbr/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Desktop/IpotekaCalc/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/IpotekaCalc/src/app/api/cbr/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
