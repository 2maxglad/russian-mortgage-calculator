var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/prices/route.js")
R.c("server/chunks/7d77c_next_77ec2f46._.js")
R.c("server/chunks/[root-of-the-server]__dfb6a66d._.js")
R.c("server/chunks/Desktop_IpotekaCalc__next-internal_server_app_api_prices_route_actions_9139b145.js")
R.m("[project]/Desktop/IpotekaCalc/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/IpotekaCalc/src/app/api/prices/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Desktop/IpotekaCalc/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/IpotekaCalc/src/app/api/prices/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
