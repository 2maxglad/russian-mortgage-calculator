module.exports = [
"[project]/Desktop/IpotekaCalc/.next-internal/server/app/api/prices/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_IpotekaCalc__next-internal_server_app_api_prices_route_actions_9139b145.js.map