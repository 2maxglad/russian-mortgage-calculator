module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/Desktop/IpotekaCalc/src/app/api/cbr/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$IpotekaCalc$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/IpotekaCalc/node_modules/next/server.js [app-route] (ecmascript)");
;
async function GET() {
    try {
        // Получаем ключевую ставку с сайта ЦБ (парсим HTML, так как JSON API требует авторизации)
        const keyRateResponse = await fetch('https://www.cbr.ru/key-indicators/', {
            headers: {
                'Accept': 'text/html',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            next: {
                revalidate: 3600
            } // Cache for 1 hour
        });
        let keyRate = 21; // Fallback: текущая ключевая ставка (декабрь 2024)
        let inflationRate = 8.9; // Fallback: текущая инфляция
        if (keyRateResponse.ok) {
            const html = await keyRateResponse.text();
            // Парсим ключевую ставку из HTML
            // Ищем паттерн "Ключевая ставка" и значение после него
            const keyRateMatch = html.match(/Ключевая ставка[^<]*<[^>]*>[^<]*<[^>]*>([0-9,\.]+)/);
            if (keyRateMatch) {
                keyRate = parseFloat(keyRateMatch[1].replace(',', '.'));
            }
            // Парсим инфляцию
            const inflationMatch = html.match(/Инфляция[^<]*<[^>]*>[^<]*<[^>]*>([0-9,\.]+)/);
            if (inflationMatch) {
                inflationRate = parseFloat(inflationMatch[1].replace(',', '.'));
            }
        }
        // Рекомендуемая ставка по депозитам (обычно ключевая ставка - 1-2%)
        const depositRate = Math.max(keyRate - 2, keyRate * 0.9);
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$IpotekaCalc$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: {
                keyRate,
                inflationRate,
                depositRate,
                date: new Date().toLocaleDateString('ru-RU'),
                source: 'cbr.ru'
            }
        });
    } catch (error) {
        console.error('Error fetching CBR data:', error);
        // Fallback данные на декабрь 2024
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$IpotekaCalc$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to fetch CBR data',
            data: {
                keyRate: 21,
                inflationRate: 8.9,
                depositRate: 19,
                date: '13.12.2024',
                source: 'fallback'
            }
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__9cf8c20a._.js.map