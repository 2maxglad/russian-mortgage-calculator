module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/Desktop/IpotekaCalc/src/app/api/prices/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$IpotekaCalc$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/IpotekaCalc/node_modules/next/server.js [app-route] (ecmascript)");
;
async function GET(request) {
    const searchParams = request.nextUrl.searchParams;
    const type = searchParams.get('type') || '1';
    const region = searchParams.get('region') || '2'; // 2 = Москва
    const period = searchParams.get('period') || '2'; // Default: 1 year
    try {
        const response = await fetch(`https://msk.restate.ru/action/graph2/data/?region=${region}&type=${type}&period=${period}&influence=1&money=&metro=&area=&okrug=&op=1&form=9&sy=1&cjs=1`, {
            headers: {
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            next: {
                revalidate: 3600
            } // Cache for 1 hour
        });
        if (!response.ok) {
            throw new Error(`API responded with status: ${response.status}`);
        }
        const data = await response.json();
        // Extract latest price data
        const rows = data.rows || [];
        const lastRow = rows[rows.length - 1];
        // Get price per sqm (new buildings is column 1, secondary is column 2)
        const newBuildingPrice = lastRow ? lastRow[1] : null;
        const secondaryPrice = lastRow ? lastRow[2] : null;
        const date = lastRow ? lastRow[0] : null;
        // Calculate average apartment prices based on typical sizes
        const sizes = {
            '1': 50,
            '2': 38,
            '3': 55,
            '4': 75,
            '5': 100,
            '6': 28 // Studio
        };
        const avgSize = sizes[type] || 50;
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$IpotekaCalc$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: {
                date,
                type,
                pricePerSqm: {
                    newBuilding: Math.round(newBuildingPrice || 0),
                    secondary: Math.round(secondaryPrice || 0)
                },
                averagePrice: {
                    newBuilding: Math.round((newBuildingPrice || 0) * avgSize),
                    secondary: Math.round((secondaryPrice || 0) * avgSize)
                },
                avgSize,
                history: rows.map((row)=>({
                        date: row[0],
                        newBuilding: row[1],
                        secondary: row[2]
                    }))
            }
        });
    } catch (error) {
        console.error('Error fetching prices:', error);
        // Return fallback data
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$IpotekaCalc$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to fetch prices',
            data: {
                date: '09.12.2025',
                type,
                pricePerSqm: {
                    newBuilding: 519306,
                    secondary: 475564
                },
                averagePrice: {
                    newBuilding: 519306 * 50,
                    secondary: 475564 * 50
                },
                avgSize: 50,
                history: []
            }
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__dfb6a66d._.js.map