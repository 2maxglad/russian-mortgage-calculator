module.exports = [
"[project]/Desktop/IpotekaCalc/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_IpotekaCalc__next-internal_server_app_page_actions_7dd127b1.js.map