module.exports = [
"[project]/Desktop/IpotekaCalc/.next-internal/server/app/api/cbr/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_IpotekaCalc__next-internal_server_app_api_cbr_route_actions_346dd46c.js.map