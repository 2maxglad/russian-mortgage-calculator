(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_IpotekaCalc_src_e0ac2ee0._.js",
  "static/chunks/7d77c_recharts_es6_util_593c814f._.js",
  "static/chunks/7d77c_recharts_es6_component_476543c4._.js",
  "static/chunks/7d77c_recharts_es6_state_6fd06376._.js",
  "static/chunks/7d77c_recharts_es6_cartesian_c8cd95f6._.js",
  "static/chunks/7d77c_recharts_es6_ca9b7f33._.js",
  "static/chunks/7d77c_tailwind-merge_dist_bundle-mjs_mjs_e0fde45c._.js",
  "static/chunks/7d77c_@radix-ui_1e07ff56._.js",
  "static/chunks/7d77c_@reduxjs_toolkit_edf923d0._.js",
  "static/chunks/7d77c_@radix-ui_c7f87f85._.js",
  "static/chunks/7d77c_@floating-ui_6525eeb2._.js",
  "static/chunks/7d77c_8b03ffb8._.js"
],
    source: "dynamic"
});
