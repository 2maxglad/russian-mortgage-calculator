(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c9bdb289._.js",
  "static/chunks/7d77c_next_dist_compiled_react-dom_ffc65947._.js",
  "static/chunks/7d77c_next_dist_compiled_react-server-dom-turbopack_06f8200c._.js",
  "static/chunks/7d77c_next_dist_compiled_next-devtools_index_0e91e518.js",
  "static/chunks/7d77c_next_dist_compiled_07667c1c._.js",
  "static/chunks/7d77c_next_dist_client_f67c312f._.js",
  "static/chunks/7d77c_next_dist_a2bcb227._.js",
  "static/chunks/7d77c_@swc_helpers_cjs_a0ea370c._.js"
],
    source: "entry"
});
