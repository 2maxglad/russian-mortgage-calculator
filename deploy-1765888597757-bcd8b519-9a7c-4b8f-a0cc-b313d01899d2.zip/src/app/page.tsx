import MortgageCalculator from "@/components/MortgageCalculator";

export default function Home() {
  return <MortgageCalculator />;
}
